//
// Created by Florin Hangan on 18/01/2019.
//

#ifndef LAB4_UTILS_H
#define LAB4_UTILS_H

int generateRange(int x, int y);


#endif //LAB4_UTILS_H
